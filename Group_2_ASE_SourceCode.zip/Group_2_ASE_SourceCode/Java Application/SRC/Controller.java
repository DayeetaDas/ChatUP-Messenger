/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package test;

// imports for the Server class
import java.io.*;

import java.net.URL;
import java.util.ResourceBundle;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.control.TextArea;
import javafx.scene.control.Label;
import javafx.scene.Scene;
import javafx.scene.Parent;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import javax.swing.JFileChooser;


/**
 *
 * @author Dayeeta
 */
public class Controller implements Initializable {
    
    String name;
    private Stage stage;
    private Scene scene;
    private Parent root;
    
    // elements of Login Page
    @FXML
    private TextField textField_Username;
    @FXML
    private TextField textField_Password;
    @FXML
    private Button Login;
    @FXML
    private Button Register;
    @FXML
    private Label label_login;
    
    // elements in Profile Page
    @FXML
    private Button pHome;
    @FXML
    private Button pProfile;
    @FXML
    private Button pContacts;
    @FXML
    private Button pGroupChat;
    @FXML
    private Button pExit;
    @FXML
    private Button pEdit;
    @FXML
    private Label img_label;
    
    //elements in Contacts Page
    
    @FXML
    private Button cHome;
    @FXML
    private Button cProfile;
    @FXML
    private Button cContacts;
    @FXML
    private Button cGroupChat;
    @FXML
    private TextField cName;
    @FXML
    private TextField cContact;
    @FXML
    private Button cAddContact;
    @FXML
    private Button cDisplayContacts;
    @FXML
    private Button cStartChat;
    @FXML
    public TextField cChatName;
    @FXML
    private Button cExit;
    @FXML
    private TextArea ctextArea;
    
    
    // defining functions in Home page
    @FXML
    private void Login_OnAction(ActionEvent event) throws IOException{
        
        if (event.getSource() == Login) {
            
            String username = textField_Username.getText();
            String password = textField_Password.getText();
            
            String content;
            StringBuilder str_read = new StringBuilder();
            BufferedReader br = new BufferedReader(new FileReader("D://Study Mat//GUI Java Client Server//Test//register.txt"));
            while ((content = br.readLine()) != null){

                str_read.append(content);
            }
            br.close();
            String[] kvPairs = str_read.toString().split(";");
            for(String kvPair : kvPairs){

                String[] kv = kvPair.split("=");
                String name = kv[0];
                String pass = kv[1];
            
                if(username.equals("") && password.equals(""))
                {
                    label_login.setText("Please fill in your details...");
                }
           
                if(username.equals(name) && password.equals(pass))
                {
                    stage = (Stage) Login.getScene().getWindow();
                    root = FXMLLoader.load(getClass().getResource("Profile.fxml"));
                    Scene scene = new Scene(root);
                    stage.setScene(scene);
                    stage.show();
                }
                
                if(username.equals(name) && !password.equals(pass))
                {
                    label_login.setText("Wrong login information. Please try again...");
                }
                
                if(!username.equals(name))
                {
                    label_login.setText("User does not exist. Please register...");
                }
                
            }
            
        }

    }
    
    @FXML
    private void Register_OnAction(ActionEvent event) throws IOException{
        
        if (event.getSource() == Register) {
            
            String username = textField_Username.getText();
            String password = textField_Password.getText();
            
            String content;
            StringBuilder str_read = new StringBuilder();
            BufferedReader br = new BufferedReader(new FileReader("D://Study Mat//GUI Java Client Server//Test//register.txt"));
            while ((content = br.readLine()) != null){

                str_read.append(content);
            }
            br.close();
            String[] kvPairs = str_read.toString().split(";");
            for(String kvPair : kvPairs){

                String[] kv = kvPair.split("=");
                String name = kv[0];
                String pass = kv[1];
                
                if(!username.equals(name))
                {
                    StringBuilder str = new StringBuilder();
                    BufferedWriter writer = new BufferedWriter(new FileWriter("D://Study Mat//GUI Java Client Server//Test//register.txt"));
                    str.append(str_read);
                    str.append(username + "=" + password + ";");
                    writer.write(str.toString());
                    writer.close();
                    label_login.setText("Registration complete...");
                }
                if(username.equals(name))
                {
                    label_login.setText("User already exists...");
                }
            }
        }
    }
    
    // defining functions in Profile Page
    @FXML
    private void pHome_OnAction(ActionEvent event) throws IOException{
        
        if (event.getSource() == pHome) {
            stage = (Stage) pHome.getScene().getWindow();
            root = FXMLLoader.load(getClass().getResource("Home.fxml"));
        }
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
    
    @FXML
    private void pProfile_OnAction(ActionEvent event) throws IOException{
        
        if (event.getSource() == pProfile) {
            stage = (Stage) pProfile.getScene().getWindow();
            root = FXMLLoader.load(getClass().getResource("Profile.fxml"));
        }
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
    
    @FXML
    private void pContacts_OnAction(ActionEvent event) throws IOException{
        
        if (event.getSource() == pContacts) {
            stage = (Stage) pContacts.getScene().getWindow();
            root = FXMLLoader.load(getClass().getResource("Contacts.fxml"));
        }
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
    
    @FXML
    private void pGroupChat_OnAction(ActionEvent event) throws Exception{
        
        if (event.getSource() == pGroupChat) {
             chatMultiServer.Run();
        }
    }
    
    @FXML
    private void pExit_OnAction(ActionEvent event) throws IOException{
        
        if (event.getSource() == pExit) {
            System.exit(0);
        }
    }
    
    @FXML
    private void pEdit_OnAction(ActionEvent event) throws IOException{
        
        if (event.getSource() == pEdit) {
            FileChooser fc = new FileChooser();
            File selectedFile = fc.showOpenDialog(null);
            if (selectedFile != null) {
                Image img = new Image(selectedFile.toURI().toString());
                ImageView view = new ImageView(img);
                img_label.setGraphic(view);
            }
        }
    }
    
    // defining functions in the Contacts Page
    
    @FXML
    private void cHome_OnAction(ActionEvent event) throws IOException{
        
        if (event.getSource() == cHome) {
            stage = (Stage) cHome.getScene().getWindow();
            root = FXMLLoader.load(getClass().getResource("Home.fxml"));
        }
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
    
    @FXML
    private void cProfile_OnAction(ActionEvent event) throws IOException{
        
        if (event.getSource() == cProfile) {
            stage = (Stage) cProfile.getScene().getWindow();
            root = FXMLLoader.load(getClass().getResource("Profile.fxml"));
        }
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
    
    @FXML
    private void cContacts_OnAction(ActionEvent event) throws IOException{
        
        if (event.getSource() == cContacts) {
            stage = (Stage) cContacts.getScene().getWindow();
            root = FXMLLoader.load(getClass().getResource("Contacts.fxml"));
        }
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
    
    @FXML
    private void cGroupChat_OnAction(ActionEvent event) throws Exception{
        
        if (event.getSource() == cGroupChat) {
             chatMultiServer.Run();
        }
    }
    
    @FXML
    private void cAddContact_OnAction(ActionEvent event) throws IOException{
        
        String content;
        StringBuilder str_read = new StringBuilder();
        BufferedReader br = new BufferedReader(new FileReader("D://Study Mat//GUI Java Client Server//Test//Contacts.txt"));
        while ((content = br.readLine()) != null){
 
            str_read.append(content);
        }
        br.close();
        
        String name = cName.getText();
        String contact = cContact.getText();
        StringBuilder str = new StringBuilder();
        StringBuilder str_write = new StringBuilder();
        str.append(name + " : " + contact + "\n");
        ctextArea.setText(ctextArea.getText()+ str.toString());
        str_write.append(str_read + ctextArea.getText());
        BufferedWriter writer = new BufferedWriter(new FileWriter("D://Study Mat//GUI Java Client Server//Test//Contacts.txt"));
        writer.write(str_write.toString());
        writer.close();
    }
    
    @FXML
    private void cDisplayContacts_OnAction(ActionEvent event) throws IOException{
        
        String content;
        StringBuilder str_read = new StringBuilder();
        BufferedReader br = new BufferedReader(new FileReader("D://Study Mat//GUI Java Client Server//Test//Contacts.txt"));
        while ((content = br.readLine()) != null){
 
            str_read.append(content);
        }
        br.close();
        ctextArea.setText("");
        ctextArea.setText(ctextArea.getText()+ str_read.toString());
    }
    
    @FXML
    private void cStartChat_OnAction(ActionEvent event) throws IOException{
        
        name = cChatName.getText();
        chatServer.Run();
    }
    
    @FXML
    private void cExit_OnAction(ActionEvent event) throws IOException{
        
        if (event.getSource() == cExit) {
            System.exit(0);
        }
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
}
