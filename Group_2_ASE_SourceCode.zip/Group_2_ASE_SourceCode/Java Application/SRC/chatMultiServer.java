/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package test;

import java.io.*;
import java.net.*;
import java.util.ArrayList;

/**
 *
 * @author Dayeeta
 */
public class chatMultiServer {
    
    static ArrayList<String> userNames = new ArrayList<String>();
    static ArrayList<PrintWriter> printWriters = new ArrayList<PrintWriter>();
    
    
    
    public static void Run() throws Exception{
        
        System.out.println("Waiting for client...");
        ServerSocket ss = new ServerSocket(3000);
        while(true){
            
            Socket soc = ss.accept();
            System.out.println("Connection established");
            ConversationHandler handler = new ConversationHandler(soc);
            handler.start();
            
        }
    }
    
}

class ConversationHandler extends Thread
{
    Socket socket;
    BufferedReader in;
    PrintWriter out;
    String name;
    PrintWriter pw;
    static FileWriter fw;
    static BufferedWriter bw;
    
    public ConversationHandler(Socket socket) throws IOException{
        
        this.socket = socket;
        fw = new FileWriter("D://Study Mat//GUI Java Client Server//Test//ChatServer-Logs.txt", true);
        bw = new BufferedWriter(fw);
        pw = new PrintWriter(bw, true);
        
        
    }
    public void run(){
        
        try{
            
            in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            out = new PrintWriter(socket.getOutputStream(), true);
            int count = 0;
            while (true){
                
                if(count > 0)
                {
                    out.println("NAME ALREADY EXISTS");
                }
                else
                {
                    out.println("NAME REQUIRED");
                }
                
                name = in.readLine();
                
                if(name == null)
                {
                    return;
                }
                
                if(!chatMultiServer.userNames.contains(name)){
                    
                    chatMultiServer.userNames.add(name);
                    break;
                }
                count++;
            }
            
            out.println("NAME ACCEPTED" + name);
            chatMultiServer.printWriters.add(out);
            
            while(true)
            {
                String message = in.readLine();
                if(message == null)
                {
                    return;
                }
                
                pw.println(name + ": " + message);
                for (PrintWriter writer : chatMultiServer.printWriters)
                {
                    writer.println(name + ":" + message);
                }
            }
            
        }catch(Exception e){
            
            System.out.println(e);
        }
    }
}
